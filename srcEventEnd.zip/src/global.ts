export const Global = {
    ENDPOINT: 'http://dummy.restapiexample.com/api/v1',
    GET_EMPLOYEES_LIST: "/employees",
    GET_EMPLOYEE_DETAIL: "/employee/",
    PUT_UPDATE_EMPLOYEE: "/update/",
    POST_CREATE_EMPLOYEE: "/create",
    DELETE_EMPLOYEE: "/delete/",
}